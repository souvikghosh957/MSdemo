package com.home.bff.exceptionhandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.RestClientException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.netflix.client.ClientException;

@RestControllerAdvice
public class HomeBFFExceptionHandler extends ResponseEntityExceptionHandler{
	
	
	@ExceptionHandler(RestClientException.class)
	public final ResponseEntity<ErrorDetails> handleRestClinetException(RestClientException ex) {
		
		return new ResponseEntity<>(new ErrorDetails(1, ex.getMessage()),
				HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(ValueNotFound.class)
	public final ResponseEntity<ErrorDetails> handleServiceNotAvailable(ValueNotFound ex) {
		
		return new ResponseEntity<>(new ErrorDetails(1, "No data found"),
				HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(NullPointerException.class)
	public final ResponseEntity<ErrorDetails> handleArithmeticException(NullPointerException ex) {
		
		return new ResponseEntity<>(new ErrorDetails(1, ex.getMessage()),
				HttpStatus.BAD_REQUEST);
	}

	
	@ExceptionHandler(ArithmeticException.class)
	public final ResponseEntity<ErrorDetails> handleNullPonterException(ArithmeticException ex) {
		
		return new ResponseEntity<>(new ErrorDetails(1, ex.getMessage()),
				HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(ClientException.class)
	public final ResponseEntity<ErrorDetails> handleArithmeticException(ClientException ex) {
		
		return new ResponseEntity<>(new ErrorDetails(1, "Back end service is not available"),
				HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ErrorDetails> handleException(Exception ex) {
		
		return new ResponseEntity<>(new ErrorDetails(1, "Some internal server error"),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
