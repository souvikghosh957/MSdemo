package com.home.bff.rest;

import java.io.IOException;
import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.home.bff.exceptionhandler.ValueNotFound;
import com.home.bff.model.EmployeDetails;
import com.home.bff.proxy.FeignClientDemoProjectProxy;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.ribbon.proxy.annotation.Hystrix;

@RestController
public class HomeBFFController {

	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	FeignClientDemoProjectProxy feignClientDemoProjectProxy;
		
	@GetMapping("/rest/emp-details/{id}")
	public ResponseEntity<Object> getEmpDetails(@PathVariable("id") String id) throws IOException
	{
		
		String url="http://localhost:8282/rest/get-name/";
		
		ResponseEntity<String> searchResponse=restTemplate.getForEntity(URI.create(url+id), String.class);
		
		ObjectMapper mapper = new ObjectMapper();
		JsonNode root = mapper.readTree(searchResponse.getBody());
		return new ResponseEntity<>(root, HttpStatus.OK);
		
	}

	@GetMapping("/home-bff/get-all-name")
	public List<Object> getAllNames()
	{
		return feignClientDemoProjectProxy.getAllName();
		
	}
	
	@GetMapping("/home-bff/get-name/{id}")
	public Optional<EmployeDetails> getName(@PathVariable("id") int id)
	{
		Optional<EmployeDetails> empDetails=feignClientDemoProjectProxy.getName(id);
		if(empDetails.isPresent())
		{
		if((empDetails.get().getSalary()>1000) && (empDetails.get().getSalary()<=10000))
			empDetails.get().setTax(10);
		else if((empDetails.get().getSalary()>10000) && (empDetails.get().getSalary()<=20000))
			empDetails.get().setTax(15);
		else if(empDetails.get().getSalary()>15000 && empDetails.get().getSalary()<=30000)
			empDetails.get().setTax(25);
		}
		else
		{
			throw new ValueNotFound("No value found");
		}
		
		return empDetails;
	}
	
	@GetMapping("/home-bff/arithmetic-exception")
	public List<Object> testExceptionHandling()
	{
		throw new ArithmeticException("ArithmeticException is thrown from the HomeBFFController");
	}

	@GetMapping("/test-hystrix")
	@HystrixCommand(fallbackMethod="getInfoFallbackMethod")
	public EmployeDetails getInfo()
	{
		throw new NullPointerException("NullPointerException is thrown from the HomeBFFController");
	}
	
	public EmployeDetails getInfoFallbackMethod()
	{
		return new EmployeDetails(1,"Fallback Method is Getting Executed",000,0,00);
		
	}
	
	
}
