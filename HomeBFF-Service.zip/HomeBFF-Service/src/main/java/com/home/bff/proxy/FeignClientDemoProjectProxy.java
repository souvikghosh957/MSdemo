package com.home.bff.proxy;

import java.util.List;
import java.util.Optional;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.home.bff.model.EmployeDetails;

@FeignClient(name="employee-info")
@RibbonClient(name="employee-info")
public interface FeignClientDemoProjectProxy {

	@GetMapping("/rest/get-all")
	public List<Object> getAllName();
	
	@GetMapping("/rest/get-name/{id}")
	public Optional<EmployeDetails> getName(@PathVariable("id") int id);
	
}
