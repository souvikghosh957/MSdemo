package com.home.bff.exceptionhandler;

public class ValueNotFound extends RuntimeException{

	public ValueNotFound(String message)
	{
		super(message);
	}
}
