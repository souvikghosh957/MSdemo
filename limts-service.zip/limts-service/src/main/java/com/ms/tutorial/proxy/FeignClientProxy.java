package com.ms.tutorial.proxy;

import java.util.List;
import java.util.Optional;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


//@FeignClient(name="spring-demo-project",url="localhost:8282")
@FeignClient(name="employee-info")
@RibbonClient(name="employee-info")
public interface FeignClientProxy {
	
	@GetMapping("/rest/get-all")
	public List<Object> getAllName();
	
	@GetMapping("/rest/get-name/{id}")
	public Optional<Object> getName(@PathVariable("id") int id);
	
	
}
