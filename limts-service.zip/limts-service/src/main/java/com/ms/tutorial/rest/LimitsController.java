package com.ms.tutorial.rest;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.ms.tutorial.model.LimitConfiguration;
import com.ms.tutorial.proxy.FeignClientProxy;

@RestController
public class LimitsController {
	
/*	@Value("${limits.maximum}")
	private String max;
	
	@Value("${limits.minimum}")
	private String min;*/
	
	@Autowired
	private FeignClientProxy feignClientProxy;
	
	@Autowired
	LimitConfiguration limitConfig;
	
	
	@GetMapping("/limit")
	public LimitConfiguration getValue()
	{
		return new LimitConfiguration(limitConfig.getMaximum(),limitConfig.getMinimum());
		
	}
	
	@GetMapping("/limit/get-all-name")
	public List<Object> getAllNames()
	{
		return feignClientProxy.getAllName();
		
	}
	
	@GetMapping("/limit/get-name/{id}")
	public Optional<Object> getName(@PathVariable("id") int id)
	{
		return feignClientProxy.getName(id);
		
	}


}
