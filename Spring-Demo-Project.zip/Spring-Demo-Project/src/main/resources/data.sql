insert into Employee(id,emp_name,salary,port)
values(10001,'Arun',5000,0);
insert into Employee(id,emp_name,salary,port)
values(10002,'John',15000,0);
insert into Employee(id,emp_name,salary,port)
values(10003,'Sam',25000,0);
